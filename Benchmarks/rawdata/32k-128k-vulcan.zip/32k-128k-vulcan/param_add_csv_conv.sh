#!/bin/bash

#bone-be parameters
#TIMESTEP=1
#ELEMENT_SIZE="5 6 8 9 11 13 14 16 17 19 20 21 23 24 25"
#EPP="5,5,4" #"2,2,2;4,4,2;4,4,4;8,4,4;8,8,4"
#CART="4,4,2;8,4,4;8,8,8;16,16,8;32,16,16" #;32,32,32;64,64,32"
#PHY_PARAM=5
#------------------------#

#Test case!
TIMESTEP="2"
ELEMENT_SIZE="8 9 13 16 19 21 24"
EPP="5,5,4" #"2,2,2;4,4,2;4,4,4;8,8,4"
CART="64,64,32"
PHY_PARAM=5
#--------------------------#

#Creating array stack for EPP and CART 
CART_stack=($(echo $CART | tr ";" "\n"))
epp_stack=$(echo $EPP | tr ";" "\n")
#---------------------------#

count=0		#counting the number of files not present in the folder

for index in ${!CART_stack[*]}
do
  #bone-BE Cartesian coordinate
  CART_X=$(echo ${CART_stack[$index]} | tr "," " " | awk '{print $1}')
  CART_Y=$(echo ${CART_stack[$index]} | tr "," " " | awk '{print $2}')
  CART_Z=$(echo ${CART_stack[$index]} | tr "," " " | awk '{print $3}')
  NP=$((CART_X*CART_Y*CART_Z))

  for EC in $epp_stack
  do
    #Calculating EL_X, EL_Y,EL_Z from epp_stack
    EL_X=$(echo $EC | tr "," " " | awk '{print $1}')
    EL_Y=$(echo $EC | tr "," " " | awk '{print $2}')
    EL_Z=$(echo $EC | tr "," " " | awk '{print $3}')
    Exyz=$((EL_X*EL_Y*EL_Z))

    for ES in $ELEMENT_SIZE
    do
    FILE=be-es$ES'ec'$Exyz'np'$NP.csv
      if [ -f $FILE ];
      then
        echo "$TIMESTEP,$ES,$EL_X,$EL_Y,$EL_Z,$CART_X,$CART_Y,$CART_Z,$PHY_PARAM" > param.csv
        mv be-es$ES'ec'$Exyz'np'$NP.csv temp.csv
        paste -d, -s temp.csv > csv_temp.csv 
        cat param.csv csv_temp.csv > be-es$ES'ec'$Exyz'np'$NP.csv
        rm temp.csv param.csv
        rm csv_temp.csv
        echo $FILE
      else
	echo '> be-es'$ES'ec'$Exyz'np'$NP'.csv does not exist - Ignoring request! <'
	count=$((count+1))
      fi
    done
  done
done

if [ $count -ne 0 ];
then
  echo "$count files were missing!"
fi

echo "* * * DONE * * *"
