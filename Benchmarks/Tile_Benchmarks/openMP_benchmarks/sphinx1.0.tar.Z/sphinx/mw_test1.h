/*
$Log: mw_test1.h,v $
Revision 1.2  1999/09/29 00:23:47  bronis
removed most restrictions on ACKER variation

Revision 1.1.1.1  1999/05/11 16:50:02  srtaylor
CVS repository setup for sphinx

*/

/* $Id: mw_test1.h,v 1.2 1999/09/29 00:23:47 bronis Exp $ */

void mw_init_dummy (measurement_t *ms);
void mw_init_Waitsome (measurement_t *ms);
void mw_init_Waitany (measurement_t *ms);
void mw_init_Recv_AS (measurement_t *ms);
void mw_init_Send (measurement_t *ms);
void mw_init_Ssend (measurement_t *ms);
void mw_init_Isend (measurement_t *ms);
void mw_init_Bsend (measurement_t *ms);











